// import app from "./details.js"
// // import express from "express"
// // import bodyParser from 'body-parser'
// // import cors from 'cors'

// // const app = express()

// // app.use(express.json());
// // app.use(bodyParser.urlencoded({ extended: false }))
// // app.use(express.json());
// // app.use((req, res, next) => {
// //     res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
// //     next();
// // });
// // app.use(cors())

// // const connection_config = {
// //     useNewUrlParser: true,
// //     useUnifiedTopology: true,
// // }

// app.get("http://localhost:5000/Notion", (req, res) => {
//     console.log("yo yo")
// })

