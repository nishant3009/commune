// const http = require("http")
// const express = require("express")
// const cors = require("cors")
// import { socketIO } from "socket.io"
// import server from "./details.js"
// import cors from 'cors'

// const io = socketIO(server, {
//   cors: {
//     origin: "*",
//   },
// });









