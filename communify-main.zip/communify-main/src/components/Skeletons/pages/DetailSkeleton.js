import React from 'react'

import FormSkeleton from "../FormSkeleton.js"

function DetailSkeleton() {
    return (
        <>
            <FormSkeleton />
        </>
    )
}

export default DetailSkeleton