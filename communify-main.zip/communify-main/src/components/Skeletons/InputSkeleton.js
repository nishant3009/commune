import React from 'react'
import "./InputSkeleton.css"
function InputSkeleton() {
    return (

        < html>
            <head>
            </head>
            <body>
                <div className='flex'>
                    <div class="InputSkeleton"></div>
                    <div className='SendButtonSkeleton'></div>
                    <div className='NotionButtonSkeleton'></div>
                </div>
            </body>
        </html>
    )
}

export default InputSkeleton
