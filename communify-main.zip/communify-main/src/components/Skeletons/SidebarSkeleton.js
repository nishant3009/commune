import React from 'react'
import "./SidebarSkeleton.css"
function SidebarSkeleton() {
    return (
        <>
            < html>
                <head>
                </head>
                <body>
                    <div class="skeleton">
                        <div class="skeleton-item"></div>
                        <div class="skeleton-item"></div>
                        <div class="skeleton-item"></div>
                    </div>
                </body>
            </html>
        </>

    )
}

export default SidebarSkeleton
