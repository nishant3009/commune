import React from 'react'
import "./AiBarSkeleton.css"
function AiBarSkeleton() {
    return (

        < html>
            <head>
            </head>
            <body>
                <div class="AiBarSkeleton">
                    <div class="AiBarSkeleton-item"></div>
                    <div class="AiBarSkeleton-item"></div>
                    <div class="AiBarSkeleton-item"></div>
                    <div class="AiBarSkeleton-item"></div>
                    <div class="AiBarSkeleton-item"></div>
                </div>
            </body>
        </html>

    )
}

export default AiBarSkeleton
