import React from 'react'

function LoaderIcon() {
    return (
        <div>
            <p>Loading .....</p>
        </div>
    )
}

export default LoaderIcon
